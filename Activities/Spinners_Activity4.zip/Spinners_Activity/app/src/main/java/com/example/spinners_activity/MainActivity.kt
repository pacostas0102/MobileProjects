package com.example.spinners_activity

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val check1:CheckBox = findViewById(R.id.check1)
        val check2:CheckBox = findViewById(R.id.check2)

        val banda1 = findViewById<ImageView>(R.id.banda1)
        val banda2 = findViewById<ImageView>(R.id.banda2)
        val banda3 = findViewById<ImageView>(R.id.banda3)
        val multi = findViewById<ImageView>(R.id.multiplicador)
        val toler = findViewById<ImageView>(R.id.tolerancia)

        val sp1:Spinner = findViewById(R.id.sp1)
        val bands = resources.getStringArray(R.array.colors)
        val adaptador = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands)
        sp1.adapter = adaptador

        check1.setOnClickListener {
            if(check1.isChecked){
                check2.setChecked(false)
                sp1.setEnabled(false)
                banda1.setBackgroundColor(Color.TRANSPARENT)
            }else{
                sp1.setEnabled(true)
            }
        }
        check2.setOnClickListener {
            if(check2.isChecked){
                check1.setChecked(false)
                sp1.setEnabled(true)
            }
        }

        sp1.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands[p2], Toast.LENGTH_SHORT).show()

                var pos = sp1.selectedItemPosition
                when(pos){
                    1 -> banda1.setBackgroundColor(Color.BLACK)
                    2 -> banda1.setBackgroundColor(Color.BLACK)
                    3 -> banda1.setBackgroundColor(Color.BLACK)
                    4 -> banda1.setBackgroundColor(Color.BLACK)
                    5 -> banda1.setBackgroundColor(Color.BLACK)
                    6 -> banda1.setBackgroundColor(Color.BLACK)
                    7 -> banda1.setBackgroundColor(Color.BLACK)
                    8 -> banda1.setBackgroundColor(Color.BLACK)
                    9 -> banda1.setBackgroundColor(Color.BLACK)
                    10 -> banda1.setBackgroundColor(Color.BLACK)
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp2:Spinner = findViewById(R.id.sp2)
        val bands2 = resources.getStringArray(R.array.colors)
        val adaptador2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands2)
        sp2.adapter = adaptador2

        sp2.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands2[p2], Toast.LENGTH_SHORT).show()

                var pos2 = sp2.selectedItemPosition
                when(pos2){
                    1 -> banda2.setBackgroundColor(Color.BLUE)
                    2 -> banda2.setBackgroundColor(Color.BLUE)
                    3 -> banda2.setBackgroundColor(Color.BLUE)
                    4 -> banda2.setBackgroundColor(Color.BLUE)
                    5 -> banda2.setBackgroundColor(Color.BLUE)
                    6 -> banda2.setBackgroundColor(Color.BLUE)
                    7 -> banda2.setBackgroundColor(Color.BLUE)
                    8 -> banda2.setBackgroundColor(Color.BLUE)
                    9 -> banda2.setBackgroundColor(Color.BLUE)
                    10 -> banda2.setBackgroundColor(Color.BLUE)
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp3:Spinner = findViewById(R.id.sp3)
        val bands3 = resources.getStringArray(R.array.colors)
        val adaptador3 = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands3)
        sp3.adapter = adaptador3

        sp3.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands3[p2], Toast.LENGTH_SHORT).show()

                var pos3 = sp3.selectedItemPosition
                when(pos3){
                    1 -> banda3.setBackgroundColor(Color.RED)
                    2 -> banda3.setBackgroundColor(Color.RED)
                    3 -> banda3.setBackgroundColor(Color.RED)
                    4 -> banda3.setBackgroundColor(Color.RED)
                    5 -> banda3.setBackgroundColor(Color.RED)
                    6 -> banda3.setBackgroundColor(Color.RED)
                    7 -> banda3.setBackgroundColor(Color.RED)
                    8 -> banda3.setBackgroundColor(Color.RED)
                    9 -> banda3.setBackgroundColor(Color.RED)
                    10 -> banda3.setBackgroundColor(Color.RED)
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp4:Spinner = findViewById(R.id.sp4)
        val multiplicador = resources.getStringArray(R.array.multiplicador)
        val adaptador4 = ArrayAdapter(this, android.R.layout.simple_spinner_item, multiplicador)
        sp4.adapter = adaptador4

        sp4.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, multiplicador[p2], Toast.LENGTH_SHORT).show()

                var pos4 = sp4.selectedItemPosition
                when(pos4){
                    1 -> multi.setBackgroundColor(Color.YELLOW)
                    2 -> multi.setBackgroundColor(Color.YELLOW)
                    3 -> multi.setBackgroundColor(Color.YELLOW)
                    4 -> multi.setBackgroundColor(Color.YELLOW)
                    5 -> multi.setBackgroundColor(Color.YELLOW)
                    6 -> multi.setBackgroundColor(Color.YELLOW)
                    7 -> multi.setBackgroundColor(Color.YELLOW)
                    8 -> multi.setBackgroundColor(Color.YELLOW)
                    9 -> multi.setBackgroundColor(Color.YELLOW)
                    10 -> multi.setBackgroundColor(Color.YELLOW)
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp5:Spinner = findViewById(R.id.sp5)
        val tolerancia = resources.getStringArray(R.array.tolerancia)
        val adaptador5 = ArrayAdapter(this, android.R.layout.simple_spinner_item, tolerancia)
        sp5.adapter = adaptador5

        sp5.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, tolerancia[p2], Toast.LENGTH_SHORT).show()

                var pos5 = sp5.selectedItemPosition
                when(pos5){
                    1 -> toler.setBackgroundColor(Color.GREEN)
                    2 -> toler.setBackgroundColor(Color.GREEN)
                    3 -> toler.setBackgroundColor(Color.GREEN)
                    4 -> toler.setBackgroundColor(Color.GREEN)
                    5 -> toler.setBackgroundColor(Color.GREEN)
                    6 -> toler.setBackgroundColor(Color.GREEN)
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
    }
}