package com.example.spinners_activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sp1:Spinner = findViewById(R.id.sp1)
        val bands = resources.getStringArray(R.array.colors)
        val adaptador = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands)
        sp1.adapter = adaptador

        sp1.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands[p2], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp2:Spinner = findViewById(R.id.sp2)
        val bands2 = resources.getStringArray(R.array.colors)
        val adaptador2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands2)
        sp2.adapter = adaptador2

        sp2.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands2[p2], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp3:Spinner = findViewById(R.id.sp3)
        val bands3 = resources.getStringArray(R.array.colors)
        val adaptador3 = ArrayAdapter(this, android.R.layout.simple_spinner_item, bands3)
        sp3.adapter = adaptador3

        sp3.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, bands3[p2], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp4:Spinner = findViewById(R.id.sp4)
        val multiplicador = resources.getStringArray(R.array.multiplicador)
        val adaptador4 = ArrayAdapter(this, android.R.layout.simple_spinner_item, multiplicador)
        sp4.adapter = adaptador4

        sp4.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, multiplicador[p2], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        val sp5:Spinner = findViewById(R.id.sp5)
        val tolerancia = resources.getStringArray(R.array.tolerancia)
        val adaptador5 = ArrayAdapter(this, android.R.layout.simple_spinner_item, tolerancia)
        sp5.adapter = adaptador5

        sp5.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(this@MainActivity, tolerancia[p2], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
    }
}