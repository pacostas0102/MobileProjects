package com.sigmotoa.lifecycle

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var currentSong: MutableList<Int> =mutableListOf(R.raw.money3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var fab_play :Button= findViewById(R.id.fab_play)
        var fab_pause :Button= findViewById(R.id.fab_pause)
        var fab_stop :Button= findViewById(R.id.fab_stop)
        val seekbar: SeekBar = findViewById(R.id.seekbar)

        //mediaPlayer = MediaPlayer.create(this, R.raw.money3)
        //mediaPlayer?.start()
        controlSound(currentSong[0], fab_play, fab_pause, fab_stop,seekbar)

        Log.i("LifeCycle", "OnCreate")


    }

    private fun controlSound (id:Int, fab_play:Button, fab_pause:Button, fab_stop:Button,seekbar: SeekBar){

        fab_play.setOnClickListener{
            if (mediaPlayer == null){
                mediaPlayer = MediaPlayer.create(this,R.raw.money3)
                Log.d("MainActivity", "ID: ${mediaPlayer!!.audioSessionId}")
                initialiseSeekBar(seekbar)
            }
            mediaPlayer?.start()
            Log.d("MainActivity", "DURATION: ${mediaPlayer!!.duration/1000} seconds")
        }

        fab_pause.setOnClickListener{
            if (mediaPlayer !== null) {
                mediaPlayer?.pause()
                Log.d("MainActivity", "PAUSED AT: ${mediaPlayer!!.currentPosition/1000} seconds")
            }

        }

        fab_stop.setOnClickListener{
            if (mediaPlayer !== null){
                mediaPlayer?.seekTo(0)
                mediaPlayer?.stop()
                mediaPlayer?.reset()
                mediaPlayer?.release()
                mediaPlayer = null
            }
        }

        seekbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p2) {
                    mediaPlayer?.seekTo(p1)
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                    mediaPlayer?.seekTo(0)
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
            }

        })
    }

    private fun initialiseSeekBar(seekbar: SeekBar){
        seekbar.max = mediaPlayer!!.duration

        val handler= Handler()
        handler.postDelayed(object:Runnable{
            override fun run() {
                try{
                    seekbar.progress = mediaPlayer!!.currentPosition
                    handler.postDelayed(this, 1000)
                }catch (e: Exception) {
                    seekbar.progress = 0
                }
            }
        }, 0)
    }



}